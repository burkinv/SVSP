#include <__SVSPTextureRenderer.h>

        __SVSPTextureRenderer::__SVSPTextureRenderer(UINT uiWidth, UINT uiHeight){}
        __SVSPTextureRenderer::~__SVSPTextureRenderer() {}
VOID    __SVSPTextureRenderer::Clear(DWORD dwColor) {}
VOID    __SVSPTextureRenderer::Begin() {}
VOID    __SVSPTextureRenderer::End() {}
VOID    __SVSPTextureRenderer::GetBackbufferData(struct IMAGE* pImage) {}
VOID    __SVSPTextureRenderer::SetOnScreenRenderingModule(class __SVSPModule *pkModule) {}
VOID    __SVSPTextureRenderer::SetDefaultShaders() {}

